from pathlib import Path
##GENERATING OUTPUT
pathout = Path('output')
pathout.mkdir(parents=True)
print(pathout)