# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['guanin']

package_data = \
{'': ['*']}

install_requires = \
['PyQt6-Qt6>=6.4.0,<7.0.0',
 'PyQt6-sip>=13.4.0,<14.0.0',
 'PyQt6>=6.4.0,<7.0.0',
 'ergene>=1.2.8,<2.0.0',
 'fpdf>=1.7.2,<2.0.0',
 'jinja2>=3.0,<4.0',
 'mlxtend>=0.21.0,<0.22.0',
 'numpy>=1.23.4,<2.0.0',
 'pandas>=1.5.1,<2.0.0',
 'pip>=22.3.1,<23.0.0',
 'scipy>=1.9.3,<2.0.0',
 'seaborn>=0.12.1,<0.13.0',
 'setuptools>=65.5.1,<66.0.0',
 'sklearn>=0.0,<0.1']

entry_points = \
{'console_scripts': ['guanin = guanin.gui:main']}

setup_kwargs = {
    'name': 'guanin',
    'version': '0.1.0',
    'description': '',
    'long_description': '\n<!-- PROJECT LOGO -->\n<br />\n<div align="center">\n  <a href="https://github.com/julimontoto/guanin">\n    <img src=![image/logoguanin.png]("image/logoguanin.png") width="156" height="156">\n  </a>\n\n<h3 align="center">GUANIN</h3>\n\n  <p align="center">\n    | GUi-driven Analyser for Nanostring Interactive Normalization |\n    <br />\n    <a href="https://github.com/julimontoto/guanin"><strong>Explore the docs »</strong></a>\n    <br />\n    <br />\n    <a href="https://github.com/github_username/repo_name">View Demo</a>\n    ·\n    <a href="https://github.com/github_username/repo_name/issues">Report Bug</a>\n    ·\n    <a href="https://github.com/github_username/repo_name/issues">Request Feature</a>\n  </p>\n</div>\n\n\n\n<!-- TABLE OF CONTENTS -->\n<details>\n  <summary>Table of Contents</summary>\n  <ol>\n    <li>\n      <a href="#about-the-project">About The Project</a>\n      <ul>\n      </ul>\n    </li>\n    <li>\n      <a href="#getting-started">Getting Started</a>\n      <ul>\n        <li><a href="#prerequisites">Prerequisites</a></li>\n        <li><a href="#installation">Installation</a></li>\n      </ul>\n    </li>\n    <li><a href="#usage">Usage</a></li>\n    <li><a href="#roadmap">Roadmap</a></li>\n    <li><a href="#contributing">Contributing</a></li>\n    <li><a href="#license">License</a></li>\n    <li><a href="#contact">Contact</a></li>\n    <li><a href="#acknowledgments">Acknowledgments</a></li>\n  </ol>\n</details>\n\n\n\n<!-- ABOUT GUANIN -->\n\n\n[![Product Name Screen Shot][product-screenshot]]([https://example.com](https://i.imgur.com/TBTcTnm.png))\n\nAquí hay una captura representativa de GUANIN (que no se ve)\n\n<p align="right">(<a href="#top">back to top</a>)</p>\n\n\n<!-- GETTING STARTED -->\n\n### Prerequisites\n\nGUANIN should run under Linux, MacOS and Windows.\n\n### Installation\n\nAssuming you have a Python >= 3.9 installed:\n   \n    $ pip install --user https://github.com/julimontoto/guanin/releases/download/0.1.0/GUANIN-0.1.0.tar.gz\n\nCheck INSTALL.txt for further details.\n\n<p align="right">(<a href="#top">back to top</a>)</p>\n\n\n\n<!-- USAGE EXAMPLES -->\n\n## Running\n\n### The CLI\n\nOpen a console and from any path, run the following:\n\n    $ guanin-cli\n\n### The GUI\n\nA simple GUI is included using [pyQT6](https://pypi.org/project/PyQt6/).\n\nFrom a console, launch the GUI with:\n\npython3 guanin-gui.py\n\nThis *executable* is installed in your PATH (TBD!). You can find it and launch\nit with a double-click.\nAlthough, running it through the console will provide further information about the execution of the program.\n\n\n<!-- LICENSE -->\n## License\n\nDistributed under the GPL License. See `LICENSE.txt` for more information.\n\n<p align="right">(<a href="#top">back to top</a>)</p>\n\n\n\n<!-- For developers -->\n## For developers\n\nPull requests are only welcome if both the following are true:\n\n1. They include at least some test.\n\n2. They solve a bug.\n\nWe don\'t accept pull requests of enhancements, new requirements, "It would be\nnice if...", and so on. If that is your case, fork and develop.\n\n### For internal usage only\n\nTo create a new release, follow the steps:\n\n1. Bump the version at `nqcview/__init__.py`.???\n\n2. Create a new bundle **locally** with `python -m build`.\n\n3. Check you can install the bundle **locally**, in a fresh Virtualenv, with:\n\n    `$ pip install NanostringQC-0.1.0.tar.gz`????\n\n    **AND**\n\n     `$ pip install NanostringQC-0.1.0-py3-none-any.whl`????\n\n4. Check it\'s working as expected, both the CLI and the GUI.\n\n5. Bump the version in this Readme, in the install link above.\n\n6. Put the code under the CVS, **tag it with version**, and push.\n\n7. At Github, create a new Release, selecting the tag from above, and attach\n  the binaries tested in [3].\n\n\n<!-- CONTACT -->\n## Contact\n\nJulián Montoto-Louzao - [@julimontoto](https://twitter.com/julimontoto) - juli.mlouzao@gmail.com\n\nGUANIN: [https://github.com/julimontoto/guanin](https://github.com/julimontoto/guanin)\n\n<p align="right">(<a href="#top">back to top</a>)</p>\n\n\n\n\n<!-- MARKDOWN LINKS & IMAGES -->\n<!-- https://www.markdownguide.org/basic-syntax/#reference-style-links -->\n[contributors-shield]: https://img.shields.io/github/contributors/github_username/repo_name.svg?style=for-the-badge\n[contributors-url]: https://github.com/github_username/repo_name/graphs/contributors\n[forks-shield]: https://img.shields.io/github/forks/github_username/repo_name.svg?style=for-the-badge\n[forks-url]: https://github.com/github_username/repo_name/network/members\n[stars-shield]: https://img.shields.io/github/stars/github_username/repo_name.svg?style=for-the-badge\n[stars-url]: https://github.com/github_username/repo_name/stargazers\n[issues-shield]: https://img.shields.io/github/issues/github_username/repo_name.svg?style=for-the-badge\n[issues-url]: https://github.com/github_username/repo_name/issues\n[license-shield]: https://img.shields.io/github/license/github_username/repo_name.svg?style=for-the-badge\n[license-url]: https://github.com/github_username/repo_name/blob/master/LICENSE.txt\n[linkedin-shield]: https://img.shields.io/badge/-LinkedIn-black.svg?style=for-the-badge&logo=linkedin&colorB=555\n[linkedin-url]: https://linkedin.com/in/linkedin_username\n[product-screenshot]: images/screenshot.png\n',
    'author': 'julimontoto',
    'author_email': 'juli.mlouzao@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
